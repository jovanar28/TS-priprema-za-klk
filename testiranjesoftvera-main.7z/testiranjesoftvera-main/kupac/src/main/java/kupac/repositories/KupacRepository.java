package kupac.repositories;

import org.springframework.data.repository.CrudRepository;

import kupac.model.Kupac;

public interface KupacRepository extends CrudRepository<Kupac, Long> {

}
