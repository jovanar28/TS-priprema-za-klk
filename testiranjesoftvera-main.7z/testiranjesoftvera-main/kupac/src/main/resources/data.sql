INSERT INTO `kupac` (`ime`,`prezime`,`email`) VALUES ('Petar','Petrovic','ppetrovic@gmail.com');
INSERT INTO `kupac` (`ime`,`prezime`,`email`) VALUES ('Marko','Markovic','mmarkovic@gmail.com');
INSERT INTO `kupac` (`ime`,`prezime`,`email`) VALUES ('Stefan','Stefanovic','sstefanovic@gmail.com');


INSERT INTO `tekuci_racun` (`broj_racuna`,`stanje`,`kupac_id`) VALUES ('212345678',3000.0,1);
INSERT INTO `tekuci_racun` (`broj_racuna`,`stanje`,`kupac_id`) VALUES ('444345678',15000.0,1);
INSERT INTO `tekuci_racun` (`broj_racuna`,`stanje`,`kupac_id`) VALUES ('555345678',2100.0,2);
INSERT INTO `tekuci_racun` (`broj_racuna`,`stanje`,`kupac_id`) VALUES ('666345678',130000.0,2);

