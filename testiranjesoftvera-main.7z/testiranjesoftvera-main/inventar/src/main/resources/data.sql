INSERT INTO `proizvod` (`naziv`,`kategorija`,`cena`,`stanje`) VALUES ('sampon','kozmetika',100.0,100);
INSERT INTO `proizvod` (`naziv`,`kategorija`,`cena`,`stanje`) VALUES ('sapun','kozmetika',50.0,80);
INSERT INTO `proizvod` (`naziv`,`kategorija`,`cena`,`stanje`) VALUES ('hleb','prehrambeni',70.0,90);
INSERT INTO `proizvod` (`naziv`,`kategorija`,`cena`,`stanje`) VALUES ('mleko','prehrambeni',65.0,100);

