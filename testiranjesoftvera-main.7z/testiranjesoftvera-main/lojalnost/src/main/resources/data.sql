INSERT INTO `broj_kupovina` (`email`,`broj_kupovina`) VALUES ('ppetrovic@gmail.com',10);
INSERT INTO `broj_kupovina` (`email`,`broj_kupovina`) VALUES ('mmarkovic@gmail.com',30);
INSERT INTO `broj_kupovina` (`email`,`broj_kupovina`) VALUES ('sstefanovic@gmail.com',2);

INSERT INTO `tip_kupca` (`tip`,`popust`,`min_broj_kupovina`) VALUES ('srebrni',10,10);
INSERT INTO `tip_kupca` (`tip`,`popust`,`min_broj_kupovina`) VALUES ('zlatni',20,25);
