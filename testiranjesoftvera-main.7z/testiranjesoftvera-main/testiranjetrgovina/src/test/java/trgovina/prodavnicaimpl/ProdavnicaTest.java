package trgovina.prodavnicaimpl;

import org.junit.Test;
import trgovina.main.Prodavnica;
import trgovina.repositories.ProizvodRepository;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.util.List;

public class ProdavnicaTest {

    @Test
    void testUcitavanjaProizvoda(){
        //stub
        ProizvodRepository proizvodRepository=mock(ProizvodRepository.class);

        when(proizvodRepository.vratiSveRazliciteProizvode()).thenReturn(List.of("sampon","sapun"));
        when(proizvodRepository.vratiStanjeZaProizvod("sampon")).thenReturn(30);
        when(proizvodRepository.vratiStanjeZaProizvod("sapun")).thenReturn(20);

        Prodavnica p=new Prodavnica();
        p.setProizvodRepository(proizvodRepository);

    }
}
