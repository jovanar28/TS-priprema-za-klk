package trgovina.moj;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import trgovina.dtos.KupacDTO;
import trgovina.dtos.RacunDTO;
import trgovina.main.KupovinaService;
import trgovina.main.Prodavnica;
import trgovina.model.Racun;
import trgovina.services.EmailService;
import trgovina.services.ProdavnicaInventarService;
import trgovina.services.ProdavnicaKupacService;
import trgovina.services.ProdavnicaLojalnostService;

import java.time.LocalDate;

import static reactor.core.publisher.Mono.when;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class RacunTest {

    //gledamo da udjemo u svaki if i else u klasi prodavnica

    //gde god ima @autowired on je mockovao bean
    //@injectmocks->private constructor
    @MockBean
    private ProdavnicaInventarService inventarService;
    @MockBean
    private ProdavnicaKupacService kupacService;
    @MockBean
    private ProdavnicaLojalnostService lojalnostService;

    private KupovinaService service;

    //emailservice nema konstruktor mi ga setujemo obicno pa se koristi @mock a ne @mock bean
    @Mock
    private EmailService emailService;

    @Autowired
    private Prodavnica prodavnica;

    //test sve da prodje
    @Test
    void izdajRacunTest(){
       // Racun racun=new Racun();

        KupacDTO kupacDTO=new KupacDTO(1L,"Ime","Prezime","email@gmail.com");

        Mockito.when(kupacService.kupacZaId(1)).thenReturn(kupacDTO);

        Mockito.when(inventarService.vratiStanjeZaProizvod("sampon")).thenReturn(4);
        Mockito.when(inventarService.vratiStanjeZaProizvod("sapun")).thenReturn(6);

        Mockito.when(inventarService.vratiCenuZaProizvod("sampon")).thenReturn(100.00);
        Mockito.when(inventarService.vratiCenuZaProizvod("sapun")).thenReturn(50.00);

        //inventarService.umanjiStanjeProizvoda(proizvod, brojArtikalaNaRacunu);
        //ovo se ne mockuje: 1.jer je void nista ne vraca-->da vraca neki error onda moze
        //2. mokovali smo stanje (4,6)

        Mockito.when(lojalnostService.vratiPopustZaKupca("email@gmail.com")).thenReturn(20);

        Racun racun=new Racun("id", LocalDate.now());
        racun.setZatvoren(true);
        //KupacDTO kupac = kupacService.kupacZaId(r.getKupacId()); zbog ovog getKupacId
        racun.setKupacId(1);
        racun.dodajArtikal("sampon",2);
        racun.dodajArtikal("sapun",4);


        RacunDTO racunDTO=prodavnica.izdajRacun(racun);


        assertAll(()-> assertEquals(racunDTO.getImeIPrezimeKupca(),"Ime Prezime"),
                ()->  assertEquals(racunDTO.getUkupnaCenaBezPdv(),400),
                ()->    assertEquals(racunDTO.getUkupnaCenaSaPdv(),480),
                ()->    assertEquals(racunDTO.getUkupnaCenaSaPopustom(),384));

        verify(kupacService).kupacZaId(1);

        //treba dodati times 2
        verify(inventarService,times(2)).vratiStanjeZaProizvod(anyString());
        verify(inventarService,times(2)).vratiCenuZaProizvod(anyString());
        verify(inventarService).umanjiStanjeProizvoda("sampon",2);
        //ovaj matcher anyString korisitmo sa matcherom eq
        verify(inventarService).umanjiStanjeProizvoda(anyString(),eq(2));
        verify(inventarService).umanjiStanjeProizvoda("sapun",4);

        verify(lojalnostService).vratiPopustZaKupca(anyString());


    }
    @Test
    void manjakArtikala() {
        // Racun racun=new Racun();

        KupacDTO kupacDTO = new KupacDTO(1L, "Ime", "Prezime", "email@gmail.com");

        Mockito.when(kupacService.kupacZaId(1)).thenReturn(kupacDTO);

        Mockito.when(inventarService.vratiStanjeZaProizvod("sampon")).thenReturn(4);
        Mockito.when(inventarService.vratiStanjeZaProizvod("sapun")).thenReturn(6);

        Mockito.when(inventarService.vratiCenuZaProizvod("sampon")).thenReturn(100.00);
        Mockito.when(inventarService.vratiCenuZaProizvod("sapun")).thenReturn(50.00);


        Mockito.when(lojalnostService.vratiPopustZaKupca("email@gmail.com")).thenReturn(20);

        Racun racun = new Racun("id", LocalDate.now());
        racun.setZatvoren(true);
        racun.setKupacId(1);
        //izmena
        racun.dodajArtikal("sampon", 12);
        racun.dodajArtikal("sapun", 4);

        RacunDTO racunDTO = prodavnica.izdajRacun(racun);

        assertAll(() -> assertEquals(racunDTO.getImeIPrezimeKupca(), "Ime Prezime"),

                () -> assertEquals(racunDTO.getUkupnaCenaBezPdv(), 600),
                () -> assertEquals(racunDTO.getUkupnaCenaSaPdv(), 720),
                () -> assertEquals(racunDTO.getUkupnaCenaSaPopustom(), 576));

        verify(kupacService).kupacZaId(1);

        //treba dodati times 2
        verify(inventarService, times(2)).vratiStanjeZaProizvod(anyString());
        verify(inventarService, times(2)).vratiCenuZaProizvod(anyString());
        //izmena
        verify(inventarService).umanjiStanjeProizvoda("sampon", 4);

        //ovaj matcher anyString korisitmo sa matcherom eq
        verify(inventarService).umanjiStanjeProizvoda(anyString(), eq(2));
        verify(inventarService).umanjiStanjeProizvoda("sapun", 4);

        verify(lojalnostService).vratiPopustZaKupca(anyString());

        }

        @Test
        void nijeZatvorenRacun(){
            Racun racun=new Racun("id", LocalDate.now());
            racun.setZatvoren(false);
            racun.setKupacId(1);
            racun.dodajArtikal("sampon",2);
            racun.dodajArtikal("sapun",4);

            RacunDTO res=prodavnica.izdajRacun(racun);

            assertNull(res);
        }

        //za ovo smo dodali get izdati racuni ali na klk ne menjamo kod
        @Test
        void izdatRacunTest(){
            Racun racun=new Racun("id", LocalDate.now());
            racun.setZatvoren(true);
            racun.setKupacId(1);
            racun.dodajArtikal("sampon",2);
            racun.dodajArtikal("sapun",4);

            RacunDTO racunDTO=new RacunDTO();
            racunDTO.setRacunId("id");
            prodavnica.getIzdatiRacuni().add(racunDTO);

            RacunDTO res=prodavnica.izdajRacun(racun);

            assertEquals(racunDTO,res);
        }

        @Test
        void nemaArtikala(){
            KupacDTO kupacDTO = new KupacDTO(1L, "Ime", "Prezime", "email@gmail.com");

            Mockito.when(kupacService.kupacZaId(1)).thenReturn(kupacDTO);

            Mockito.when(inventarService.vratiStanjeZaProizvod("sampon")).thenReturn(4);
            Mockito.when(inventarService.vratiStanjeZaProizvod("sapun")).thenReturn(6);

            Mockito.when(inventarService.vratiCenuZaProizvod("sampon")).thenReturn(100.00);
            Mockito.when(inventarService.vratiCenuZaProizvod("sapun")).thenReturn(50.00);

            Mockito.when(lojalnostService.vratiPopustZaKupca("email@gmail.com")).thenReturn(20);

            Racun racun=new Racun("id", LocalDate.now());
            racun.setZatvoren(true);
            racun.setKupacId(1);

            RacunDTO racunDTO = prodavnica.izdajRacun(racun);

            assertAll(() -> assertEquals(racunDTO.getImeIPrezimeKupca(), "Ime Prezime"),

                    () -> assertEquals(racunDTO.getUkupnaCenaBezPdv(), 0),
                    () -> assertEquals(racunDTO.getUkupnaCenaSaPdv(), 0),
                    () -> assertEquals(racunDTO.getUkupnaCenaSaPopustom(), 0));


            verify(kupacService).kupacZaId(1);
            verify(lojalnostService).vratiPopustZaKupca(anyString());

        }


        /**DRUGI ZADATAK**/
        @Test
        void izdajRacunEmailomTest(){

            KupacDTO kupacDTO = new KupacDTO(1L, "Ime", "Prezime", "email@gmail.com");

            Mockito.when(kupacService.kupacZaId(1)).thenReturn(kupacDTO);

            Mockito.when(inventarService.vratiStanjeZaProizvod("sampon")).thenReturn(4);
            Mockito.when(inventarService.vratiStanjeZaProizvod("sapun")).thenReturn(6);

            Mockito.when(inventarService.vratiCenuZaProizvod("sampon")).thenReturn(100.00);
            Mockito.when(inventarService.vratiCenuZaProizvod("sapun")).thenReturn(50.00);

            Mockito.when(lojalnostService.vratiPopustZaKupca("email@gmail.com")).thenReturn(20);

            Racun racun=new Racun("id", LocalDate.now());
            racun.setZatvoren(true);
            racun.setKupacId(1);
            racun.dodajArtikal("sampon",2);
            racun.dodajArtikal("sapun",4);

            Mockito.when(emailService.sendEmail(anyString(),anyString(),eq(null))).thenReturn(true);
            //argument capture
            prodavnica.setEmailService(emailService);
            prodavnica.izdajRacunEmailom(racun);

            verify(kupacService,times(2)).kupacZaId(1);
            //verify(emailService).sendEmail("email@gmail.com","Racun izda Ime Prezime",null);
            //mockito argument capture
        }

    }
