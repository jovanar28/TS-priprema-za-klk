package trgovina.moj;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import trgovina.dtos.KupacDTO;
import trgovina.dtos.RacunDTO;
import trgovina.main.Prodavnica;
import trgovina.model.Racun;
import trgovina.services.EmailService;
import trgovina.services.ProdavnicaInventarService;
import trgovina.services.ProdavnicaKupacService;
import trgovina.services.ProdavnicaLojalnostService;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@SpringBootTest
public class RacunTestIT {
    @Autowired
    private Prodavnica prodavnica;

    //kod integracionih testova nista ne mockujemo nego pokrecemo sve ostale servise
    @Test
    void izdajRacunTest(){

        Racun racun=new Racun("id", LocalDate.now());
        racun.setZatvoren(true);
        racun.setKupacId(1);
        racun.dodajArtikal("sampon",2);
        racun.dodajArtikal("sapun",4);

        RacunDTO racunDTO=prodavnica.izdajRacun(racun);

        assertAll(()-> assertEquals(racunDTO.getImeIPrezimeKupca(),"Petar Petrovic"),
                ()->  assertEquals(racunDTO.getUkupnaCenaBezPdv(),400),
                ()->    assertEquals(racunDTO.getUkupnaCenaSaPdv(),480),
                ()->    assertEquals(racunDTO.getUkupnaCenaSaPopustom(),432));


    }
}
