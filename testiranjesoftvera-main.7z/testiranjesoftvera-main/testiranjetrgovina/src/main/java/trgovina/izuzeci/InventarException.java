package trgovina.izuzeci;

public class InventarException extends RuntimeException {
	
	public InventarException(String msg) {
		super(msg);
	}

}
