package trgovina.izuzeci;

public class RacunException extends RuntimeException {

	
	public RacunException(String message) {
		super(message);
		
	}
	
}
