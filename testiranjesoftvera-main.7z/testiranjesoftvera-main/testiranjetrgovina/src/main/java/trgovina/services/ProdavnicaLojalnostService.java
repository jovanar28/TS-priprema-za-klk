package trgovina.services;

public interface ProdavnicaLojalnostService {
	
	public int vratiPopustZaKupca(String email);

}
