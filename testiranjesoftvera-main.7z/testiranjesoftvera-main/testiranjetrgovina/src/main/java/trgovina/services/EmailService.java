package trgovina.services;

public interface EmailService {
	
	public boolean sendEmail(String email, String subject, String poruka);

}
