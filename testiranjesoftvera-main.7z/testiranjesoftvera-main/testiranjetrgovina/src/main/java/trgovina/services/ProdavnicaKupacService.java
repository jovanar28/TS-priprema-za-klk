package trgovina.services;

import trgovina.dtos.KupacDTO;

public interface ProdavnicaKupacService {
	
	public KupacDTO kupacZaId(int id);

}
